package coursera.adventure

class GameOver(message: String) extends Exception {}
